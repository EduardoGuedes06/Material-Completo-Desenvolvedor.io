﻿namespace SkyCommerce.Data.Configuration
{
    public enum DatabaseType
    {
        SqlServer,
        MySql,
        Postgre,
        Sqlite,
        InMemory
    }
}