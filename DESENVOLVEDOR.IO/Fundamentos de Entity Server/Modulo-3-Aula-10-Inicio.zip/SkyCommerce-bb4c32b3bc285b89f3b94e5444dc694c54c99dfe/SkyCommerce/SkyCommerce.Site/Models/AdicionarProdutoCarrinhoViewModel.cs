﻿namespace SkyCommerce.Site.Models
{
    public class AdicionarProdutoCarrinhoViewModel
    {
        public string NomeUnico { get; set; }
    }
}