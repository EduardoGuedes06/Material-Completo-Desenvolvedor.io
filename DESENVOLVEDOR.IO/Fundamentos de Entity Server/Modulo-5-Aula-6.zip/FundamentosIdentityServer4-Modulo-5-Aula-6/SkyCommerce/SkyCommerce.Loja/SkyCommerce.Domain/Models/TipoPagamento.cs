﻿namespace SkyCommerce.Models
{
    public enum TipoPagamento
    {
        PayPal = 1,
        CartaoCredito = 2,
        Pix = 3
    }
}