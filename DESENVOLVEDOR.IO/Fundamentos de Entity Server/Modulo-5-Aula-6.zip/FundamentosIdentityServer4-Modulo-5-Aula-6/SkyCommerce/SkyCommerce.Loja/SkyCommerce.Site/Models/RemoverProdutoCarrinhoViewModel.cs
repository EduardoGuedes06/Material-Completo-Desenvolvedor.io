﻿namespace SkyCommerce.Site.Models
{
    public class RemoverProdutoCarrinhoViewModel
    {
        public string NomeUnico { get; set; }
    }
}
