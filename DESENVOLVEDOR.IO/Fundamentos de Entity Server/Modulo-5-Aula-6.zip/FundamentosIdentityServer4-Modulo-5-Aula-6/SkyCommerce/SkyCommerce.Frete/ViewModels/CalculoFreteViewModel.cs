﻿namespace SkyCommerce.Fretes.ViewModels
{
    public class CalculoFreteViewModel
    {
        public string Modalidade { get; set; }
        public string Descricao { get; set; }
        public decimal Valor { get; set; }

        
    }

    
}