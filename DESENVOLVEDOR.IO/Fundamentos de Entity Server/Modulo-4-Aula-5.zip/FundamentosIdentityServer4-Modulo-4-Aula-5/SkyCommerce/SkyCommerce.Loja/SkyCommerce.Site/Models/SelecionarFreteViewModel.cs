﻿namespace SkyCommerce.Site.Models
{
    public class SelecionarFreteViewModel
    {
        public string Modalidade { get; set; }
    }
}