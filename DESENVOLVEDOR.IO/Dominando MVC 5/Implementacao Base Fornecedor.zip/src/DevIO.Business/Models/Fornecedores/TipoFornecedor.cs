﻿namespace DevIO.Business.Models.Fornecedores
{
    public enum TipoFornecedor
    {
        PessoaFisica = 1,
        PessoaJuridica
    }
}