﻿using System.Web.Mvc;

namespace DevIO.AppMvc.Controllers
{
    public class BaseController : Controller
    {
    }
}