﻿using System.Web;

namespace DevIO.AppMvc
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            
        }
    }
}
