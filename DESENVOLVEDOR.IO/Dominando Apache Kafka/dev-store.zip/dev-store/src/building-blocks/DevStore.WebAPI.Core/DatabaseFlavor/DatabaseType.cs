﻿namespace DevStore.WebAPI.Core.DatabaseFlavor;

public enum DatabaseType
{
    SqlServer,
    MySql,
    Postgre,
    Sqlite,
}