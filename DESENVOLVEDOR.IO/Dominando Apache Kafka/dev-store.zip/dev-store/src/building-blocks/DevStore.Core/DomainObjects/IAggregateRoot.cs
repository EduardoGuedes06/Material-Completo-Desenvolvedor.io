﻿namespace DevStore.Core.DomainObjects
{
    public interface IAggregateRoot { }
}