namespace src.Provider
{
    public class TenantData
    {
        public string TenantId { get; set; } = "dbo";
    }
}