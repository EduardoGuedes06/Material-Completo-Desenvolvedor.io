namespace src.Domain
{
    public class Person : Abstract.BaseEntity
    {
        public string Name { get; set; }
    }
}