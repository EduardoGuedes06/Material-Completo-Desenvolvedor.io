namespace src.Domain
{
    public class Product : Abstract.BaseEntity
    {
        public string Description { get; set; }
    }
}