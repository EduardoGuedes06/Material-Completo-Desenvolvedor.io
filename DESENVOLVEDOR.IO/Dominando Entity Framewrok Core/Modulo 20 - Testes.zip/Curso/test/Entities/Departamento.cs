using System;

namespace test.Entities
{
    public class Departamento
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
        public DateTime DataCadastro { get; set; }
    }
}