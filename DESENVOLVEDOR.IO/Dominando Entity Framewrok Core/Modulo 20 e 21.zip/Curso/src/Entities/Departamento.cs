namespace src.Entities
{
    public class Departamento
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}