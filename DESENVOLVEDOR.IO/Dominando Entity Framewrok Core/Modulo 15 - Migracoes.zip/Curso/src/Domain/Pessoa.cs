namespace src.Domain
{
    public class Pessoa
    {
        public int Id { get; set; }
        public int Nome { get; set; }
        public string Telefone { get; set; }
    }
}