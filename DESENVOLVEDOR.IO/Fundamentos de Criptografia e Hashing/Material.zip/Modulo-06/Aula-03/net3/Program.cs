﻿namespace OpenSSL.Net3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DemoRSA.Demo();
            DemoECC.Demo();
        }

    }
}
