numero = 5
linha = ""
for i in range(numero):
    linha = linha + " " + str(numero)

for i in range(numero):
    print(linha)