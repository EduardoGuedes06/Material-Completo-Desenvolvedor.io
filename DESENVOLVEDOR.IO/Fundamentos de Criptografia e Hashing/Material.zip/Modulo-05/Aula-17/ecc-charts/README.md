This repository contains a set of tools and scripts
useful to learn the basics about Elliptic Curve
Cryptography.

They were created for the series of posts entitled
[Elliptic Curve Cryptography: a gentle introduction](http://andrea.corbellini.name/2015/05/17/elliptic-curve-cryptography-a-gentle-introduction/)

This is free software (MIT licensed), feel free to
improve or fork.
