e = EllipticCurve([-7,10])
e
p=e(-1,4)
q=e(-1,4)
p+q
9/4.0
-19/8.0
p = e(-3,-2)
q = e(1,2)
p+q
q
-q
p
-p
p*-1
q*-1